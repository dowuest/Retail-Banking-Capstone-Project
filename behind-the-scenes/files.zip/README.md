# Project Retrospective Tracker

A self-contained collaborative retrospective tool. No server, no install — just open the HTML file in a browser.

## How it works

Each team member:
1. Opens `RETROSPECTIVE.html` in their browser
2. Enters their name
3. Rates each process step and adds remarks
4. Adds new steps if anything is missing
5. Clicks **Mark myself as ready** when done

When all members are marked ready, the **Export Markdown** button generates `RETROSPECTIVE.md` content — copy it and commit.

## Sharing

- Commit `RETROSPECTIVE.html` to your branch
- Each teammate pulls and opens the file locally
- When everyone is ready, one person exports the Markdown, saves it as `RETROSPECTIVE.md`, and commits

## Git workflow

```bash
# 1. Create your retrospective branch
git checkout -b retrospective/sprint-1

# 2. Commit the tracker
git add RETROSPECTIVE.html
git commit -m "chore: add retrospective tracker"
git push origin retrospective/sprint-1

# 3. Share the branch link with your team
# Each person: git pull, open RETROSPECTIVE.html, fill in, sync

# 4. When all ready — export Markdown, save, commit
git add RETROSPECTIVE.md
git commit -m "docs: add sprint-1 retrospective"
git push
```

## Storage

When opened from Claude.ai, the tracker uses shared cloud storage so changes sync across all users in real time.

When opened as a standalone file (outside Claude), it falls back to `localStorage` — each person's data stays in their own browser. In that case, use the **Export Markdown** button to collect responses manually.

---

*Generated with Claude — [claude.ai](https://claude.ai)*
